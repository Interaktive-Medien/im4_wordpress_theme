<footer>
        <p>Hier kommt der Footer</p>
    </footer>
<?php wp_footer() ;?>   <!-- Hook oder Haken, ein Plug-In könnte Code nach dem Footer schreiben -->
</body>

</html>